#include <stdio.h>
#include <string.h>

#define MAX_NOME 100
#define MAX_CPF 12
#define MAX_GERAL 100
#define MAX_PLACA 7

struct Carro{
    char placa[MAX_PLACA];
    char cor[MAX_GERAL];
    char marca[MAX_GERAL];
    char modelo[MAX_GERAL];
    char cpfProprietario[MAX_CPF];
    int idProprietario;
};

struct Proprietario{
    char nome[MAX_NOME];
    char CPF[MAX_CPF];
    int id; //Chave primária    
};

void cadastrarProprietario();
void cadastrarCarros();
void consultarProprietario();

int main(){

    int aux2;
    int aux;

    printf("Cadastro de Proprietários e Carros\n");

    do
    {
        printf("Deseja cadastrar ou consultar proprietários/carros?\n");
        printf("1 - Cadastrar!\n");
        printf("2 - Consultar!\n");
        scanf("%d", &aux);
        if(aux == 1){
            cadastrarProprietario();
            cadastrarCarros();
        } else if(aux == 2){
            consultarProprietario();
            return 0;
        }

        printf("Deseja cadastrar ou consultar outros proprietários/carros?\n");
        printf("1 - SIM!\n");
        printf("2 - NÃO!\n");
        scanf("%d", &aux2);
        if (aux2 == 2){
            printf("Saindo...");
        }
        
    } while (aux2 != 2);

    return 0;
}

struct Proprietario Wp;
void cadastrarProprietario(){

    printf("\n---Cadastro de Proprietários---\n");

    FILE *cadastraProprietario;
    FILE *aux = fopen("Proprietarios.bin", "rb"); //Arquivo auxiliador para manipulação do cadastro

    fseek(aux, 0, SEEK_END); //Leva o ponteiro para o final do arquivo
    long int tamanho = ftell(aux); //Recebe a posição do ponteiro

    int auxID = 0;

    if (tamanho == 0) { 
        auxID = 0; 
    }

    cadastraProprietario = fopen("Proprietarios.bin", "rb");
    fseek(cadastraProprietario, 0, SEEK_END);

    if(ftell(cadastraProprietario) > 0) {
        fseek(cadastraProprietario, -1*sizeof(struct Proprietario), SEEK_END);
        fread(&Wp, sizeof(struct Proprietario), 1, cadastraProprietario);
        auxID = Wp.id;
    }

    fclose(cadastraProprietario);
    cadastraProprietario = fopen("Proprietarios.bin", "ab");

    printf("Digite o nome do proprietario para cadastro:\n");
    scanf("%s", Wp.nome);
    printf("Digite o CPF do proprietario para cadastro:\n");
    scanf("%s", Wp.CPF);

    Wp.id = auxID + 1; //Cria uma nova chave principal (ID)
    
    fclose(aux); 
    fwrite(&Wp, 1, sizeof(struct Proprietario), cadastraProprietario);
    fclose(cadastraProprietario);

}

void cadastrarCarros(){

    printf("\n---Cadastro de Carros---\n");

    struct Carro Wc; 

    FILE *cadastraCarro;
    cadastraCarro = fopen("Carros.bin", "ab");

    fseek(cadastraCarro, 1, SEEK_SET);
    
    printf("Digite a marca do carro:\n");
    scanf("%s", Wc.marca);
    printf("Digite o modelo do carro:\n");
    scanf("%s", Wc.modelo);
    printf("Digite a placa do carro:\n");
    scanf("%s", Wc.placa);
    printf("Digite a cor do carro:\n");
    scanf("%s", Wc.cor);
    printf("Digite o CPF do proprietario:\n");
    scanf("%s", Wc.cpfProprietario);
    
    fwrite(&Wc, 1, sizeof(struct Carro), cadastraCarro);
    fclose(cadastraCarro);

}

void consultarProprietario(){ // !! PRECISO MELHORAR A CONSULTA

    printf("\n---Consulta de Proprietários e Veículos---\n");

    struct Proprietario Rp; //ler proprietario
    struct Proprietario Cp; //consultar proprietario
    struct Carro Rc; //ler carro
    
    FILE *cadastraProprietario;
    FILE *cadastraCarro;

    cadastraProprietario = fopen("Proprietarios.bin", "rb");
    cadastraCarro = fopen("Carros.bin", "rb");

    printf("Para consulta de proprietário, informe o respectivo CPF:\n");
    scanf("%s", Cp.CPF);
    
    while(fread(&Rp, sizeof(struct Proprietario), 1, cadastraProprietario)){
        while(fread(&Rc, sizeof(struct Carro), 1, cadastraCarro)){
            if(strcmp(Cp.CPF, Rc.cpfProprietario) == 0){ // Se as informações existirem, faça:
                printf("\n Nome: %s\n", Rp.nome);
                printf("ID: %d\n", Rp.id);
                printf("CPF: %s\n", Rp.CPF);
                printf("Veículo: %s\n", Rc.modelo);
                printf("Placa: %s\n", Rc.placa);
            }
            break;
        }
    }

    fclose(cadastraProprietario);
    fclose(cadastraCarro);

}