-- -----------< Clinica Médica (Exer5 Aula4 Evolução3) > -----------
--
--               SCRIPT DE CRIAÇÃO (DDL)
-- Data criacao..........: 10/05/2023
-- Autor(es).............: Artur Rodrigues Sousa Alves
-- Baco de Dados.........: MySQL 8.0
-- Base de Dados.........: aula4exer5
--
-- PROJETO => 01 Base de Dados
--            10 Tabelas
--
--  10/05/2023 => Apagando uma tabela de cada vez sem apagar a base de dados
-- -------------------------------------------------

USE aula4exer5;

drop TABLE ENDERECO

drop TABLE MEDICO

drop TABLE PACIENTE

drop TABLE ESPECIALIDADE

drop TABLE RECEITA

drop TABLE MEDICAMENTO

drop TABLE CONSULTA

drop TABLE telefone

drop TABLE possui

drop TABLE preescreve
