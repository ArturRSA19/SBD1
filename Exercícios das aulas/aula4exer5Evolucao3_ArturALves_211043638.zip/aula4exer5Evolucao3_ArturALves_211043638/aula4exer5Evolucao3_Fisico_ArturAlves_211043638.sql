-- -----------< Clinica Médica (Exer5 Aula4 Evolução3) > -----------
--
--               SCRIPT DE CRIAÇÃO (DDL)
-- Data criacao..........: 10/05/2023
-- Autor(es).............: Artur Rodrigues Sousa Alves
-- Baco de Dados.........: MySQL 8.0
-- Base de Dados.........: aula4exer5
--
-- PROJETO => 01 Base de Dados
--            10 Tabelas
--
-- -------------------------------------------------

create database aula4exer5
default character set utf8mb4
default collate utf8mb4_general_ci;

USE aula4exer5;

CREATE TABLE ENDERECO (
    estado CHAR(60),
    cidade CHAR(60),
    bairro CHAR(60),
    rua CHAR(60),
    cep INT,
    numero INT,
    CONSTRAINT ENDERECO_PK PRIMARY KEY (cep)
); 

CREATE TABLE MEDICO (
    numeroCrm INT,
    estadoCrm char(2),
    nomeCompleto char(60),
    CONSTRAINT MEDICO_PK PRIMARY KEY (numeroCrm, estadoCrm)
);

CREATE TABLE PACIENTE (
    idPaciente INT,
    nomeCompleto CHAR(60),
    idade INT,
    sexo CHAR(9),
    cep INT,
    CONSTRAINT PACIENTE_PK PRIMARY KEY (idPaciente),
	CONSTRAINT PACIENTE_ENDERECO_FK FOREIGN KEY (cep)  REFERENCES ENDERECO (cep) ON DELETE RESTRICT
);

CREATE TABLE ESPECIALIDADE (
    nomeEspecialidade char(60),
    idEspecialidade int,
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (idEspecialidade)
);

CREATE TABLE RECEITA (
    idReceita INT,
    descricao CHAR(10),
    idConsulta INT,
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    CONSTRAINT RECEITA_CONSULTA_FK FOREIGN KEY (idConsulta)  REFERENCES CONSULTA (idConsulta) ON DELETE CASCADE
);

CREATE TABLE MEDICAMENTO (
    idMedicamento INT,
    nome CHAR(60),
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (idMedicamento)
);

CREATE TABLE CONSULTA (
    idConsulta INT,
    data DATE,
    numeroCrm INT,
    estadoCrm char(2),
    idPaciente INT,
    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta), 
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (numeroCrm, estadoCrm) REFERENCES MEDICO (numeroCrm, estadoCrm),
	CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (idPaciente) REFERENCES PACIENTE (idPaciente)
);

CREATE TABLE telefone (
    telefone INT,
    idPaciente INT,
    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (idPaciente) REFERENCES PACIENTE (idPaciente)
);

CREATE TABLE possui (
    idEspecialidade int,
    numeroCrm INT,
    estadoCrm char(2),
    CONSTRAINT possui_ESPECIALIDADE_FK FOREIGN KEY (idEspecialidade) REFERENCES ESPECIALIDADE (idEspecialidade) ON DELETE RESTRICT,
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY (numeroCrm, estadoCrm) REFERENCES MEDICO (numeroCrm, estadoCrm) ON DELETE RESTRICT
);

CREATE TABLE preescreve (
    idReceita INT,
    idMedicamento INT,
    CONSTRAINT preescreve_RECEITA_FK FOREIGN KEY (idReceita) REFERENCES RECEITA (idReceita) ON DELETE RESTRICT,
    CONSTRAINT preescreve_MEDICAMENTO_FK FOREIGN KEY (idMedicamento) REFERENCES MEDICAMENTO (idMedicamento) ON DELETE RESTRICT
);