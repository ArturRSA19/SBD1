-- -------- < Prova 1 > --------
--
--                    SCRIPT APAGA 
--
-- Data Criacao ...........: 06/06/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: ArturAlves
--
-- PROJETO => 
-- 
-- Ultimas Alteracoes
--   06/06/2023 => Criação SCRIPT Apaga, apagando as tabelas
--
-- ---------------------------------------------------------

USE ArturAlves;

DROP TABLE PESSOA;
DROP TABLE TIPOCONTATO;
DROP TABLE RELACIONAMENTO;
