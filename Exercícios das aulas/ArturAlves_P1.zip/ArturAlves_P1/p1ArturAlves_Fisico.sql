-- -------- < Prova 1 > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 06/06/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: ArturAlves
--
-- PROJETO => 
-- 
-- Ultimas Alteracoes
--   06/06/2023 => Criação SCRIPT Físico, criando tabelas 
--
-- ---------------------------------------------------------
CREATE DATABASE
	IF NOT EXISTS ArturAlves;

CREATE TABLE PESSOA(
	passaporte CHAR NOT NULL PRIMARY KEY,
    nomeCompleto CHAR NOT NULL,
    sexo CHAR NOT NULL,
    dataNascimento DATE NOT NULL,
    telefone INT NOT NULL,
    idContato INTEGER NOT NULL,
    idRelacionamento INTEGER NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY (passaporte),
    CONSTRAINT PESSOA_TIPOCONTATO_FK FOREIGN KEY (idContato) REFERENCES TIPOCONTATO(idTipoContato),
    CONSTRAINT PESSOA_RELACIONAMENTO_FK FOREIGN KEY (idRelacionamento) REFERENCES RELACIONAMENTO(idRelacionamento)
)ENGINE=InnoDB;

CREATE TABLE TIPOCONTATO(
	idTipoContato INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
    contato CHAR NOT NULL,
    nomeTipo CHAR NOT NULL,
    CONSTRAINT TIPOCONTATO_PK PRIMARY KEY (idTipoContato)
)ENGINE=InnoDB;

CREATE TABLE RELACIONAMENTO(
	idRelacionamento INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
    tipoRelacionamento CHAR NOT NULL,
    dataInicio DATE NOT NULL,
    CONSTRAINT RELACIONAMENTO_PK PRIMARY KEY (idRelacionamento)
)ENGINE=InnoDB;
