-- -------- < revisão P1 > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 31/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: revisaoP1
--
-- PROJETO => 01 Base de Dados
--         => 6 tabelas
--        
-- 
-- Ultimas Alteracoes
--   31/05/2023 => Criação do script fisico
--   31/05/2023 => Adaptação com orientações do monitor
-- ---------------------------------------------------------
CREATE DATABASE revisaoP1;

USE revisaoP1;

CREATE TABLE CONTA (
    idConta INT NOT NULL AUTO_INCREMENT,
    dtAbertura DATE NOT NULL,
    saldo DECIMAL(10, 2) NOT NULL,
    cpfCliente VARCHAR(11) NOT NULL,
    idAgencia INT NOT NULL,
    CONSTRAINT CONTA_PK PRIMARY KEY (idConta),
    CONSTRAINT CONTA_CLIENTE_FK FOREIGN KEY (cpfCliente) REFERENCES CLIENTE(cpf),
    CONSTRAINT CONTA_AGENCIA_FK FOREIGN KEY (idAgencia) REFERENCES AGENCIA(idAgencia)
)ENGINE=InnoDB;

CREATE TABLE AGENCIA (
    idAgencia INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    idEndereco INT NOT NULL,
    CONSTRAINT AGENCIA_PK PRIMARY KEY (idAgencia),
    CONSTRAINT AGENCIA_ENDERECO_PK FOREIGN KEY (idEndereco) REFERENCES ENDERECO(idEndereco)
)ENGINE=InnoDB;

CREATE TABLE ENDERECO (
    idEndereco INT NOT NULL AUTO_INCREMENT,
    rua VARCHAR(100) NOT NULL,
    numero INT NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cep VARCHAR(8) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado VARCHAR(2) NOT NULL,
    complemento VARCHAR(100),
    CONSTRAINT ENDERECO_PK PRIMARY KEY (idEndereco)
)ENGINE=InnoDB;

CREATE TABLE CLIENTE (
    cpf VARCHAR(11) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(11) NOT NULL,
    email VARCHAR(100) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo INT NOT NULL,
    idEndereco INT NOT NULL,
    CONSTRAINT CLIENTE_PK PRIMARY KEY (cpf),
    CONSTRAINT CLIENTE_ENDERECO_FK FOREIGN KEY (idEndereco) REFERENCES ENDERECO(idEndereco)
)ENGINE=InnoDB;

CREATE TABLE LANCAMENTO (
    idTransacao INT NOT NULL AUTO_INCREMENT,
    tipoOperacao VARCHAR(1) NOT NULL,
    dataTransacao DATE NOT NULL,
    horaTransacao TIME NOT NULL,
    valorTransacao DECIMAL(10, 2) NOT NULL,
    comentario VARCHAR(100),
    idConta INT NOT NULL,
    CONSTRAINT TRANSACAO_PK PRIMARY KEY (idLancamento),
    CONSTRAINT TRANSACAO_CONTA_FK FOREIGN KEY (idConta) REFERENCES CONTA(idConta)
)ENGINE=InnoDB;

CREATE TABLE EMAIL(
	email VARCHAR(100) NOT NULL,
	cpfCliente  VARCHAR(11) NOT NULL,
	CONSTRAINT EMAIL_PK Primary Key(EMAIL,cpfCliente),
	CONSTRAINT EMAIL_CLIENTE_FK Foreign Key(cpfCliente) REFERENCES CLIENTE(cpf)
)ENGINE = InnoDB;
