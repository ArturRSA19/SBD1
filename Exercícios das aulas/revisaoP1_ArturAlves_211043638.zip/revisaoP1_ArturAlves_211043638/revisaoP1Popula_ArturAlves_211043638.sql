-- -------- < revisão P1 > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 31/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: revisaoP1
--
-- PROJETO => 01 Base de Dados
--         => 5 tabelas
--        
-- Ultimas Alteracoes
--   31/05/223 => Criação do script popula: adição de 3 tuplas em cada tabela
-- ---------------------------------------------------------

USE revisaoP1; 

INSERT INTO CONTA (dtAbertura, saldo, cpfCliente, idAgencia) VALUES 
    ('2023-05-31', 1000.00, '12345678901', 1),
    ('2023-05-30', 500.50, '98765432109', 2),
    ('2023-05-29', 2000.00, '55544433322', 1);
    
INSERT INTO AGENCIA (nome, idEndereco) VALUES 
    ('Agência Central', 1),
    ('Agência Sul', 2),
    ('Agência Norte', 3);
    
INSERT INTO ENDERECO (rua, numero, bairro, cep, cidade, estado, complemento) VALUES 
    ('Rua A', 123, 'Bairro X', '12345678', 'Cidade A', 'AA', 'Complemento 1'),
    ('Rua B', 456, 'Bairro Y', '87654321', 'Cidade B', 'BB', 'Complemento 2'),
    ('Rua C', 789, 'Bairro Z', '98765432', 'Cidade C', 'CC', NULL);
    
INSERT INTO CLIENTE (cpf, nome, telefone, email, dtNascimento, sexo, idEndereco) VALUES 
    ('12345678901', 'João Silva', '999999999', 'joao@example.com', '1990-05-15', 1, 1),
    ('98765432109', 'Maria Souza', '888888888', 'maria@example.com', '1985-09-20', 2, 2),
    ('55544433322', 'Pedro Santos', '777777777', 'pedro@example.com', '1998-02-10', 1, 3);
    
INSERT INTO LANCAMENTO (tipoOperacao, dataTransacao, horaTransacao, valorTransacao, comentario, idConta) VALUES 
    ('D', '2023-05-31', '09:30:00', 500.00, 'Depósito em dinheiro', 1),
    ('S', '2023-05-30', '15:45:00', 200.50, 'Saque em caixa eletrônico', 2),
    ('T', '2023-05-29', '12:15:00', 1000.00, 'Transferência para conta XYZ', 1);





