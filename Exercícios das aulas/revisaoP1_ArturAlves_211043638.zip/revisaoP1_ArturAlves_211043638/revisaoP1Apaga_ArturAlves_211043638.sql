-- -------- < revisão P1 > --------
--
--                    SCRIPT APAGA
--
-- Data Criacao ...........: 31/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: revisaoP1
--
-- PROJETO => 01 Base de Dados
--         => 5 tabelas
--        
-- 
-- Ultimas Alteracoes
--   31/05/223 => Criação do SCRIPT "apaga"
-- ---------------------------------------------------------

USE revisaoP1;

DROP TABLE CONTA;
DROP TABLE AGENCIA;
DROP TABLE CLIENTE;
DROP TABLE ENDERECO;
DROP TABLE TRANSACAO;
DROP TABLE EMAIL;
