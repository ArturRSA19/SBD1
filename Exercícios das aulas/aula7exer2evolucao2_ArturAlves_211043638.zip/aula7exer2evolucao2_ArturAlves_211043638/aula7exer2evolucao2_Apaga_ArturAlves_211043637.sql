-- -------- < aula7exer2Evolucao2 > --------
--
--                    SCRIPT APAGA
--
-- Data Criacao ...........: 24/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula7exer2
--
-- PROJETO => 01 Base de Dados
--         => 10 tabelas
--        
-- 
-- Ultimas Alteracoes
--   24/05/223 => Criação do script
-- 	 29/05/2023 => Apaga + uma tabela
-- ---------------------------------------------------------

USE aula7exer2;

DROP TABLE VENDIDO;
DROP TABLE VENDA;
DROP TABLE RECEITA;
DROP TABLE MEDICAMENTO;
DROP TABLE PERFUME;
DROP TABLE PRODUTO;
DROP TABLE TELEFONE;
DROP TABLE FABRICANTE;
DROP TABLE TIPOEMBALAGEM;
DROP TABLE TIPOPERFUMARIA;