﻿-- -------- < Aula 10 Exercício Extra 1 > --------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 19/06/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula10extra1
--
-- PROJETO => 2 DROP TABLE
-- 
-- Ultimas Alteracoes
--   19/06/2023 => Criação do SCRIPT para apagar as tabelas da base de dados
--
-- ---------------------------------------------------------

USE aula10extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;