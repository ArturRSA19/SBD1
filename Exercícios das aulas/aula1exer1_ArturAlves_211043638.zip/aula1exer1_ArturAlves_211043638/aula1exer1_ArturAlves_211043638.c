#include <stdio.h>
#include <string.h>

#define MAX_NOME 100

struct Carro{
    int quantCarros;
    char placa[8];
    char cor[20];
    char marca[30];
    char modelo[30];
};

struct Proprietario{
    char nome[MAX_NOME];
    char CPF[12];    
};


void menu();
void cadastrarProprietario();
void cadastrarCarros();


int main(){

    int opcao;
    int aux;

    printf("-----Cadastro de Proprietários e Veículos-----\n");

    do
    {
        
        cadastrarProprietario();

        printf("Deseja cadastrar carros?\n");
        printf("1 - SIM\n");
        printf("2 - NAO\n");
        scanf("%d", &opcao);
        if(opcao==1){
            cadastrarCarros();
        } else {
            printf("Saindo...");
        }

        printf("Deseja cadastrar proprietario ou consultar?\n");
        printf("1 - SIM\n");
        printf("2 - NAO\n");
        scanf("%d", &aux);
        if(aux==2){
            printf("Saindo...");
        }


    } while ((opcao != 2) && (aux != 2));

    return 0;
}

void cadastrarProprietario(){

    FILE *cadastraProprietario;

    struct Proprietario pw; //Struct para escrita em arquivo.bin(pw = pessoa write)
    
        printf("Digite o nome da pessoa:\n");
        scanf("%s", pw.nome);
        printf("Digite o CPF:\n");
        scanf("%s", pw.CPF);

    

    cadastraProprietario = fopen("Proprietarios.bin", "ab");

    fwrite(&pw, 1, sizeof(struct Proprietario), cadastraProprietario);
    fseek(cadastraProprietario, 1, SEEK_SET);
    fclose(cadastraProprietario);

}

void cadastrarCarros(){

    struct Carro cw[100]; //Struct para escrita em arquivo.bin(cw = Veiculo write)


    int cont=0;

    FILE *cadastraCarro;


    printf("Digite a quantidade de veiculos que deseja cadastrar:\n");
    scanf("%d", &cont);
    
    cw[cont].quantCarros = cont;
    
    
    cadastraCarro = fopen("Carros.bin", "ab");
    
    for(int i = 1; i<=cw[cont].quantCarros; i++){
        printf("Digite a marca do veículo %d:\n", i);
        scanf("%s", cw[i].marca);
        printf("Digite o modelo do veículo %d:\n", i);
        scanf("%s", cw[i].modelo);
        printf("Digite a placa do veículo %d:\n", i);
        scanf("%s", cw[i].placa);
        printf("Digite a cor do veículo %d:\n", i);
        scanf("%s", cw[i].cor);


        fwrite(&cw[i], 1, sizeof(struct Carro), cadastraCarro);
        fseek(cadastraCarro, 1, SEEK_SET);
    }
    
        fclose(cadastraCarro);




    struct Proprietario pr; //pr = pessoa read
    struct Proprietario cp; //cp = consult pessoa



    FILE *cadastraProprietario;
    FILE *pesquisaCarro;

    cadastraProprietario = fopen("Proprietarios.bin", "rb");
    pesquisaCarro = fopen("Carros.bin", "rb");


    printf("Informe a pessoa que deseja procurar:\n");
    scanf("%s", cp.nome);
    
     while(fread(&pr, sizeof(struct Proprietario), 1, cadastraProprietario)){
        while(fread(&cw, sizeof(struct Carro), 1, pesquisaCarro)){
            if(strcmp(cp.nome, pr.nome) == 0){
                for(int i = 1; i<=cont; i++){
                    printf("\nNOME: %s\nCPF: %s\nVeiculo: %s %s\nPlaca: %s\nCor: %s\n", pr.nome, pr.CPF, cw[i].marca, cw[i].modelo, cw[i].placa, cw[i].cor);
                }
            }
            break;
        }
    }

    fclose(cadastraProprietario);
    fclose(pesquisaCarro);

}