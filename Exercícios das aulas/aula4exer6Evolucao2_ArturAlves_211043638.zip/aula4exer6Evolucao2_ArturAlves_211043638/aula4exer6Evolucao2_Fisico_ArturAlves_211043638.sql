﻿-- -------- < PROJETO DETRAN INFRACOES > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- date Criacao ...........: 08/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (aula4exer6) ...: bdInfracoes
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
-- 
-- Ultimas Alteracoes
--   08/05/2023 => Adicao de Tabelas. Entidades: PROPRIETARIO, VEICULO, MODELO, CATEGORIA, TIPOINFRACAO, LOCALL, INFRACAO, AGENTETRANSITO
--                                    Relacionamentos: MANTEM, DESCRITO, POSSUI, COMETE, OCORRE, TEM, REGISTRA
--   08/05/2023 => Ajustes na apresentacao da documentacao
--                 desse script.
--
-- ---------------------------------------------------------

create datebase aula4exer6
default character set utf8mb4
default collate utf8mb4_general_ci;

create table PROPRIETARIO (
  cpf int(11) not null,
  nome char(100) not null,
  telefones	int(20) not null,
	sexo char(20) not null,
	dateNascimento date not null,
	endereco char(50) not null,
	idEndereco int(10) not null,
  primary key (cpf)
);

create table VEICULO (
  placa			int(10)		not null,
	chassi			int(10)		not null,
	corPredominante	char(30)		not null,
	codigoModelo		int(6)		not null,
	codigoCategoria	int(2)		not null,
	anoFabricacao	int(10)		not null,
	cpfProprietario	int(11)		not null,
  primary key (placa),
  CONSTRAINT fk_VEICULO_PROPRIETARIO FOREIGN KEY (cpfProprietario) REFERENCES PROPRIETARIO (cpf)
);

create table MODELO (
  codigoModelo		int(6)		not null,
	nome			char(100)		not null,
	primary key (codigoModelo),
	CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (codigoModelo) REFERENCES VEICULO (codigoModelo)
);

create table CATEGORIA (
  codigoCategoria	int(2)		not null,
	nome			char(100)		not null,
	primary key (codigoModelo),
	CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (codigoCategoria) REFERENCES VEICULO (codigoCategoria)
);

create table TIPOINFRACAO (
  codigoTipoInfracao	int(6)		not null,
	nomeInfracao		char(100)		not null,
	valorInfracao		char(100)		not null,
	primary key (codigoTipoInfracao)
);

create table LOCALL (
  codigoLocal			int(20)		not null,
	posicaoGeografica		int(10) 		not null,
	velocidadePermitida		int(120)       	not null,
	primary key (codigoLocal)
);

create table INFRACAO (
  idInfracao	int(20)		not null auto_increment,
	placaVeiculo	int(10)		not null,
	dateHora		date			not null,
	codigoTipoInfracao	int(6)		not null,
	codigoLocal		int(10)		not null,
	velocidadeAferida		int(80)		not null,
	matriculaFuncionalAgenteTransito	int(10)		not null,
	primary key (idInfracao),
	CONSTRAINT TIPOINFRACAO_INFRACAO_FK FOREIGN KEY (codigoTipoInfracao) REFERENCES TIPOINFRACAO (codigoTipoInfracao)
	CONSTRAINT LOCAL_INFRACAO_FK FOREIGN KEY (codigoLocal) REFERENCES TIPOINFRACAO (codigoLocal)
	CONSTRAINT AGENTETRANSITO_INFRACAO_FK FOREIGN KEY (matriculaFuncionalAgenteTransito) REFERENCES AGENTE (matriculaFuncional)
);

create table AGENTETRANSITO (
  matriculaFuncional	int(6)		not null,
	nome			char(100)		not null,
	dateContratacao	date			not null,
	tempoServico		date			not null,
	primary key (matriculaFuncional),
);

create table MANTEM (
  placa			int(20)		not null,
	cpf			int(11)		not null,
	primary key (placa, cpf),
  CONSTRAINT MANTEM_VEICULO_FK FOREIGN KEY (placa) REFERENCES VEICULO (placa),
  CONSTRAINT MANTEM_PROPRIETARIO_FK FOREIGN KEY (cpf) REFERENCES PROPRIETARIO (cpf),
);

create table DESCRITO (
  codigoModelo	int(6)		not null,
	placa		int(10)		not null,
	primary key (placa, codigoModelo),
  CONSTRAINT DESCRITO_VEICULO_FK FOREIGN KEY (placa) REFERENCES VEICULO (placa),
  CONSTRAINT DESCRITO_MODELO_FK FOREIGN KEY (codigoModelo) REFERENCES MODELO (codigoModelo),
);

create table POSSUI (
  codigoCategoria	int(20)		not null,
	placa			int(10)		not null,
	primary key (placa, codigoCategoria),
  CONSTRAINT POSSUI_VEICULO_FK FOREIGN KEY (placa) REFERENCES VEICULO (placa),
  CONSTRAINT POSSUI_CATEGORIA_FK FOREIGN KEY (codigoCategoria) REFERENCES CATEGORIA (codigoCategoria),
);

create table COMETE (
  idInfracao		int(20)	not null auto_increment,
	placa			int(10)	not null,
	primary key (placa, idInfracao),
  CONSTRAINT COMETE_VEICULO_FK FOREIGN KEY (placa) REFERENCES VEICULO (placa),
  CONSTRAINT COMETE_INFRACAO_FK FOREIGN KEY (codigoCategoria) REFERENCES INFRACAO (idInfracao),
);

create table OCORRE (
  idInfracao		int(20)		not null,
	codigoLocal		int(10)		not null,
	primary key (codigoLocal, idInfracao),
  CONSTRAINT OCORRE_INFRACAO_FK FOREIGN KEY (idInfracao) REFERENCES INFRACAO (idInfracao),
  CONSTRAINT OCORRE_LOCALL_FK FOREIGN KEY (codigoLocal) REFERENCES LOCALL (codigoLocal),
);

create table TEM (
  idInfracao		int(20)		not null auto_increment,
	codigoTipoInfracao	int(6)		not null,
	primary key (codigoTipoInfracao, idInfracao),
  CONSTRAINT TEM_INFRACAO_FK FOREIGN KEY (idInfracao) REFERENCES INFRACAO (idInfracao),
  CONSTRAINT TEM_TIPOINFRACAO_FK FOREIGN KEY (codigoTipoInfracao) REFERENCES TIPOINFRACAO (codigoTipoInfracao),
);

create table REGISTRA (
  matriculaFuncional	int(20)		not null,
	idInfracao	int(10)		not null auto_increment,
	primary key (matriculaFuncional, idInfracao),
  CONSTRAINT REGISTRA_INFRACAO_FK FOREIGN KEY (idInfracao) REFERENCES INFRACAO (idInfracao),
  CONSTRAINT REGISTRA_AGENTETRANSITO_FK FOREIGN KEY (matriculaFuncional) REFERENCES AGENTETRANSITO (matriculaFuncional),
);