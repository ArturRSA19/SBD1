-- -------- < PROJETO DETRAN INFRACOES > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- date Criacao ...........: 10/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (aula4exer6) ...: bdInfracoes
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
-- 
-- Ultimas Alteracoes
--
--	10/05/2023 => Novo arquivo de remoção do projeto proposto como solução ao enunciado, mantendo a base de dados
--
-- ---------------------------------------------------------

create database aula4exer6
default character set utf8mb4
default collate utf8mb4_general_ci;

drop table PROPRIETARIO

drop table VEICULO

drop table MODELO

drop table CATEGORIA

drop table TIPOINFRACAO

drop table LOCALL

drop table INFRACAO

drop table AGENTETRANSITO

drop table MANTEM

drop table DESCRITO

drop table POSSUI

drop table COMETE

drop table OCORRE

drop table TEM

drop table REGISTRA