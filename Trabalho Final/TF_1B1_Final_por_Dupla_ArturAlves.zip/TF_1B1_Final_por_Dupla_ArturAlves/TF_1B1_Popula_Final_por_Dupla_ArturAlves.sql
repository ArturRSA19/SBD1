-- ------------------------------ << TF1 >> -----------------------------------
--                          SCRIPT DE POPULA (DDL)
--
-- Data Criacao ...........: 18/06/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves e Bruno Campos Ribeiro
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF1B1
--
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
-- 
-- Ultimas Alteracoes
--   18/06/2023 => Populando as tabelas com pelo menos 5 tuplas
--   03/07/2023 => Populando as 3 novas tabelas com pelo menos 5 tuplas
-- -----------------------------------------------------------------------------

USE TF_1B1_BrunoRibeiro;

INSERT INTO EDIFICACAO (nome, latitude, longitude) VALUES
    ('ICC-FAC', -15.7660, -47.8681),
    ('BCE', -15.7609, -47.8704),
    ('FCS', -15.7685, -47.8669),
    ('UAC', -15.9893, -48.0407),
    ('UAC', -15.8441, -48.1015);
    
INSERT INTO DISTRIBUIDORA (razaoSocial, sigla) VALUES
    ('Companhia de Eletricidade do Estado do Rio de Janeiro', 'CEDAE'),
    ('Companhia Paulista de Força e Luz', 'CPFL'),
    ('Companhia Energética de Minas Gerais', 'CEMIG'),
    ('Companhia Paranaense de Energia', 'COPEL'),
    ('Eletropaulo Metropolitana Eletricidade de São Paulo', 'ENEL');
    
INSERT INTO TARIFA (tusdKw, tusdMwh, te, subgrupo, modalidade, cnpj) VALUES
    (10.50, 150.00, 5.75, 'Residencial', 'Azul', 1),
    (15.25, 200.00, 7.80, 'Comercial', 'Verde', 2),
    (8.75, 120.00, 4.50, 'Residencial', 'Azul', 3),
    (12.50, 180.00, 6.80, 'Industrial', 'Verde', 4),
    (9.80, 130.00, 5.25, 'Residencial', 'Verde', 5);
    
INSERT INTO CONTRATO (dataVigencia, categoria, tensaoContratada, idTarifa) VALUES
    ('2022-01-15', 'residencial', 220, 1),
    ('2021-09-30', 'industrial', 380, 2),
    ('2023-03-10', 'comercial', 220, 3),
    ('2022-05-20', 'rural', 380, 4),
    ('2021-11-05', 'poder público', 220, 5);
    
INSERT INTO UNIDADE (sigla, nome, idEdificacao, numeroContrato) VALUES
    ('APT101', 'Apartamento 101', 1, 1),
    ('APT202', 'Apartamento 202', 2, 2),
    ('CASA01', 'Casa 01', 3, 3),
    ('LOJA01', 'Loja 01', 4, 4),
    ('SALA01', 'Sala 01', 5, 5);

INSERT INTO CAMPUS (sigla, nome, latitude, longitude, numeroUnidade) VALUES
    ('UNB', 'Campus Darcy Ribeiro', -15.7660, -47.8681, 1),
    ('UNB', 'Campus Darcy Ribeiro', -15.7609, -47.8704, 2),
    ('UNB', 'Campus Darcy Ribeiro', -15.7685, -47.8669, 3),
    ('FGA', 'Campus Gama', -15.9893, -48.0407, 4),
    ('FCE', 'Campus Ceilândia', -15.8441, -48.1015, 5);

INSERT INTO CHAVE (nome, estado, latitude, longitude) VALUES
    ('Chave A', 1, -15.7660, -47.8681),
    ('Chave B', 0, -15.7609, -47.8704),
    ('Chave C', 1, -15.7685, -47.8669),
    ('Chave D', 1, -15.9893, -48.0407),
    ('Chave E', 0, -15.8441, -48.1015);

INSERT INTO LINHA (pontoFinalLatitude, pontoFinalLongitude, pontoInicialLatitude, pontoInicialLongitude, estado, idChave) VALUES
    (-15.7660, -47.8681, -15.7573, -47.8718, 1, 1),
    (-15.7609, -47.8704, -15.7605, -47.8679, 1, 2),
    (-15.7685, -47.8669, -15.7665, -47.8649, 0, 3),
    (-15.9893, -48.0407, -15.9898, -48.0454, 1, 4),
    (-15.8441, -48.1015, -15.8441, -48.1006, 0, 5);

INSERT INTO MEDIDOR (nome, modelo, fabricante, porta, latitude, longitude, estado, idEdificacao, idLinha) VALUES
    ('Medidor 1', 'Modelo A', 'Fabricante A', 1, -15.7660, -47.8681, 1, 1, 1),
    ('Medidor 2', 'Modelo B', 'Fabricante B', 2, -15.7609, -47.8704, 0, 2, 2),
    ('Medidor 3', 'Modelo C', 'Fabricante C', 3, -15.7685, -47.8669, 1, 3, 3),
    ('Medidor 4', 'Modelo D', 'Fabricante D', 4, -15.9893, -48.0407, 1, 4, 5),
    ('Medidor 5', 'Modelo E', 'Fabricante E', 5, -15.8441, -48.1015, 0, 5, 5);
    
INSERT INTO MEDIDA (dataMedida, ip) VALUES
	('2023-06-15', 1),
    ('2023-07-02', 3),
    ('2023-04-03', 4),
    ('2023-05-19', 2),
    ('2023-03-21', 1);

INSERT INTO MEDIDAINSTANTANEA (corrente, tensao, potenciaAtiva, potenciaReativa, potenciaAparente, fatorDePotencia, dhtTensao, dhtCorrente, idMedida) VALUES
	(10.5, 220, 2000, 800, 2200, 0.9, 2.5, 1.8, 1),
    (15.2, 380, 3000, 1200, 3500, 0.85, 2.2, 1.6, 2),
    (7.8, 220, 1500, 600, 1800, 0.92, 2.4, 1.7, 3),
    (12.6, 380, 2500, 1000, 3000, 0.88, 2.3, 1.5, 2),
    (9.3, 220, 1800, 700, 2000, 0.91, 2.4, 1.6, 1);

INSERT INTO MEDIDAACUMULADA (correnteAcumulada, tensaoAcumulada, potenciaAtivaAcumulada, potenciaReativaAcumulada, potenciaAparenteAcumulada, fatorDePotenciaAcumulada, dhtTensaoAcumulada, dhtCorrenteAcumulada, idMedida) VALUES
	(10.5, 220, 2000, 800, 2200, 0.9, 2.5, 1.8, 1),
    (15.2, 380, 3000, 1200, 3500, 0.85, 2.2, 1.6, 2),
    (7.8, 220, 1500, 600, 1800, 0.92, 2.4, 1.7, 3),
    (12.6, 380, 2500, 1000, 3000, 0.88, 2.3, 1.5, 4),
    (9.3, 220, 1800, 700, 2000, 0.91, 2.4, 1.6, 2);
    
INSERT INTO EVENTO (hora, dataEvento, tipoEvento) VALUES
    ('08:30:00', '2023-06-15', 'acima'),
    ('12:45:00', '2023-06-16', 'muito acima'),
    ('18:15:00', '2023-06-17', 'dentro'),
    ('09:10:00', '2023-06-17', 'abaixo'),
    ('14:20:00', '2023-06-18', 'dentro');
    
INSERT INTO USUARIO (email, nome, senha, idCampus) VALUES
    ('pedro123@hotmail.com', 'PedroMN_12', 'Pedrorrrii11', 1),
    ('1matheus1@gmail.com', 'Matheus_11', 'asdadMatheus', 2),
    ('98carla@hotmail.com', 'Carla_98', 'Carla981723', 3),
    ('Rodrigo17@outlook.com', 'Rodrigo17', 'rodrigorr123', 4),
    ('jv_10@gmail.com', 'Jv_10', 'jv12345', 5);
