-- -------< TF1 - ENERGIA > --------
--
--                    SCRIPT APAGA (DDL)
-- 
-- Data Criacao ...........: 19/07/2023
-- Autor(es) ..............: Ana César, Ana Silva, Artur Alves, Breno Souza, Bruna Santos, Bruno Ribeiro, Bruno Kishibe, Cícero Filho, 
--                           Chaydson Aparecida, Damarcones Portos, Douglas Santos, Eric Borges, Erick Santos, Felipe Macedo

-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1_cicerofilho
-- 
-- PROJETO => 01 Base de Dados
--         => 17 Tabelas
--         => 03 perfis
--         => 03 usuarios
-- ---------------------------------------------------------

USE TF_Tema1_cicerofilho;

DROP TABLE CONTRATO;
DROP TABLE EVENTO;
DROP TABLE TIPOEVENTO;
DROP TABLE USUARIO; 
DROP TABLE PERFIL; 
DROP TABLE TARIFA; 
DROP TABLE MEDIDAACUMULADA; 
DROP TABLE MEDIDAINSTANTANEA; 
DROP TABLE MEDIDOR;
DROP TABLE pontoTransmissao;
DROP TABLE LINHATRANSMISSAO; 
DROP TABLE CHAVEELETRICA; 
DROP TABLE TIPOCHAVEELETRICA;
DROP TABLE EDIFICACAO; 
DROP TABLE UNIDADECONSUMIDORA; 
DROP TABLE CAMPUS; 
DROP TABLE DISTRIBUIDORA; 

-- USUARIOS
DROP USER 'renato';
DROP USER 'cicero';
DROP USER 'milene';

-- ROLES
DROP ROLE gestor;
DROP ROLE pesquisador;
DROP ROLE geral;
