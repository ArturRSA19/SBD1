-- -------< TF1 - ENERGIA > --------
--
--                    SCRIPT POPULA (DML)
-- 
-- Data Criacao ...........: 19/07/2023
-- Autor(es) ..............: Ana César, Ana Silva, Artur Alves, Breno Souza, Bruna Santos, Bruno Ribeiro, Bruno Kishibe, Cícero Filho, 
--                           Chaydson Aparecida, Damarcones Portos, Douglas Santos, Eric Borges, Erick Santos, Felipe Macedo

-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1_cicerofilho
-- 
-- PROJETO => 01 Base de Dados
--         => 17 Tabelas
--         => 03 perfis
--         => 03 usuarios
-- ---------------------------------------------------------


USE TF_Tema1_cicerofilho;


INSERT INTO DISTRIBUIDORA (cnpj, razaoSocial, sigla) VALUES
(03353055000196, 'Neoenergia', 'CEB-D'),
(00070698000166, 'Companhia Energética de Brasília', 'CEB'),
(98416126000146, 'Distribuidora de Energia de Formosa', 'DE-FOR'),
(84219800000198, 'Distribuidora de Anapolis', 'DIS-APS'),
(49360787000191, 'Distribuidora de Planaltina', 'DIS-PLAN'),
(92019603000153, 'Nova Energia', 'NOVA'),
(48243211000181, 'Companhia de Energia', 'CE'),
(69720712000181, 'Distribuidora de Energia do Gama', 'DE-GAM'),
(21023783000107, 'Distribuidora de Energia do DF', 'DIS-DF'),
(23836916000181, 'Distribuidora do Goiás', 'DIS-GOIAS');


INSERT INTO CAMPUS (nomeCampus, longitude, latitude, siglaCampus) VALUES
('Faculdade do Gama', -15.989622, -48.044356, 'FGA'),
('Darcy Ribeiro', -15.763314, -47.869234, 'UnB'),
('Faculdade de Ceilândia',-15.84397, -48.10136, 'FCE'),
('UnB Planaltina',-15.60077, -47.66009, 'FUP'),
('Instituto Federal de Brasília', -15.75250, -47.87747, 'IFB'),
('Campus Samambaia', -15.843623, -48.114587,'CS'),
('Faculdade de Taguatinga', -15.832447, -48.043888, 'FT'),
('Faculdade de Recursos Educacionais', -15.773625, -47.907692, 'FRE'),
('Instituto de Ciências Exatas', -15.764118, -47.864954, 'ICE'),
('Campus Aguas Claras', -15.862920, -48.005553, 'CAC');


INSERT INTO UNIDADECONSUMIDORA (numeroUnidade, nomeUnidade, siglaUnidade, idCampus) VALUES
(58297041, 'Faculdade do Gama', 'FGA', 1),
(19382567, 'Centro de Planejamento', 'CEPLAN', 2),
(73910482, 'Instituto Central de Ciencias Sul', 'ICC-SUL', 2),
(65281937, 'Instituto Central de Ciencias Norte', 'ICC-NORTE', 2),
(40732895, 'Restaurante Universitário', 'RU', 2),
(25873014, 'Biblioteca da FGA', 'BibFGA', 1),
(36498275, 'Laboratório de Informática', 'LabInfo', 1),
(52971836, 'Ginásio Poliesportivo', 'Ginásio', 2),
(89103625, 'Instituto de Letras', 'IL', 3),
(67481932, 'Laboratório de Química', 'LabQuímica', 4);


INSERT INTO EDIFICACAO (nomeEdificacao, siglaEdificacao, longitude, latitude, numeroUnidade) VALUES
('Unidade Acadêmica', 'UAC', -15.98899, -48.04463, 58297041),
('Unidade de Ensino e Docência', 'UED', -15.98951, -48.04546, 58297041),
('Laboratório de Energia', 'LTDTEA', -15.99054, -48.04435, 58297041),
('Restaurante Universitário', 'RU', -15.98938, -48.04416, 58297041),
('Faculdade de Tecnologia', 'FT', -15.76358, -47.87306, 73910482),
('Biblioteca Central', 'BCE', -15.76192, -47.87049, 19382567),
('Laboratório de Engenharia Civil', 'LEC', -15.98674, -48.04265, 40732895),
('Anfiteatro', 'ANF', -15.98783, -48.04204, 65281937),
('Instituto de Biologia', 'IB', -15.76451, -47.86963, 73910482),
('Instituto de Química', 'IQ', -15.76278, -47.86897, 36498275);


INSERT INTO TIPOCHAVEELETRICA(nomeTipoChaveEletrica) VALUES	
('Chave trifásica automática'),
('Chave trifásica transferência'),
('Chave monofásica estrela'),
('Chave monofásica reversora'),
('Chave trifásica tipo bóia'),
('Chave trifásica cerâmica'),
('Chave trifásica plástico'),
('Chave monofásica cerâmica'),
('Chave monofásica plástico'),
('Chave trifásica reta metal');


INSERT INTO CHAVEELETRICA (longitude, latitude, nomeChave, estadoChave, idTipoChaveEletrica) VALUES
(-15.961000, -48.049500, 'FGA - UAC', '1', 1),
(-15.989300, -48.045200, 'FGA - UED', '1', 2),
(-15.990300, -48.044100, 'LTDTEA', '1', 3),
(-15.989400, -48.043900, 'RU - FGA', '0', 4),
(-15.990460, -48.044448, 'Chave Lappis', '0', 5),
(-15.988900, -48.042300, 'Plan', '1', 6),
(-15.989200, -48.042500, 'Gama', '1', 7),
(-15.990800, -48.043700, 'Aguas', '0', 8),
(-15.987300, -48.042800, 'GM', '1', 9),
(-15.986900, -48.042900, 'AC', '0', 10);


INSERT INTO LINHATRANSMISSAO (estado, idChave) VALUES
(1, 1),
(1, 2),
(1, 3),
(0, 4),
(0, 5),
(1, 6),
(0, 7),
(1, 8),
(1, 9),
(0, 10);


INSERT INTO pontoTransmissao (longitude, latitude, idLinhaTransmissao) VALUES
(-15.961000, -48.049500, 1),
(-15.960800, -48.049200, 1),
(-15.960600, -48.048900, 1),
(-15.960400, -48.048600, 1),
(-15.960200, -48.048300, 1),
(-15.989500, -48.045400, 2),
(-15.989300, -48.045200, 2),
(-15.990500, -48.044300, 3),
(-15.990300, -48.044100, 3),
(-15.989400, -48.043900, 4),
(-15.989300, -48.043800, 4),
(-15.990460, -48.044448, 5),
(-15.990480, -48.044460, 5),
(-15.961100, -48.049600, 6),
(-15.961200, -48.049700, 6),
(-15.961300, -48.049800, 7),
(-15.961400, -48.049900, 7),
(-15.961500, -48.050000, 8),
(-15.990600, -48.045500, 8),
(-15.990700, -48.045600, 9),
(-15.990800, -48.045700, 9),
(-15.990900, -48.045800, 10),
(-15.989500, -48.045500, 10),
(-15.989600, -48.045600, 3),
(-15.990570, -48.044470, 4),
(-15.990580, -48.044480, 10);


INSERT INTO MEDIDOR (modelo, fabricante, ip, porta, estadoMedidor, nomeMedidor, longitude, latitude, idEdificacao, idLinhaTransmissao) VALUES
('Kron Konect', 'Kron', 1921681211, 502, '1', 'Medidor KRON KONECT', -15.98897, -48.04466, 1, 1),
('MD50 Embrasul', 'Embrasul', 1921681100, 8080, '1', 'Medidor MD50', -15.98962, -48.04555, 2, 2),
('MD30 Embrasul', 'Embrasul', 17216100200, 255, '1', 'Medidor MD30', -15.99048, -48.004434, 3, 3),
('Modelo X1000', 'Schneider Eletric', 19216100231, 530, '1', 'Medidor X1000', -15.98942, -48.04394, 4, 4),
('Modelo IEM3250', 'Siemens', 17431163200, 540, '1', 'Medidor IEM3250', -15.76360, -47.87309, 5, 5),
('Medidor Novo', 'Novo Fabricante', 1921681200, 505, '1', 'Medidor Novo', -15.98880, -48.04300, 1, 1),
('Medidor Inteligente', 'Intel', 1921681233, 512, '1', 'Medidor Inteligente', -15.98895, -48.04400, 2, 2),
('Medidor Avançado', 'Advanced Tech', 1921681205, 510, '1', 'Medidor Avançado', -15.98930, -48.04445, 3, 3),
('Medidor Smart', 'SmartTech', 1921681240, 520, '1', 'Medidor Smart', -15.98910, -48.04480, 4, 4),
('Medidor Monitor', 'MonitorCo', 1921681250, 525, '1', 'Medidor Monitor', -15.99000, -48.04500, 5, 5);

INSERT INTO MEDIDAINSTANTANEA(dhtTensaoA, dhtTensaoB, dhtTensaoC, tensaoA, tensaoB, tensaoC, potenciaAparenteA, potenciaAparenteB, potenciaAparenteC, dhtCorrenteA, dhtCorrenteB, dhtCorrenteC, potenciaReativaA, potenciaReativaB, potenciaReativaC, correnteA, correnteB, correnteC, fatorPotencia, potenciaAtivaA, potenciaAtivaB, potenciaAtivaC, dataMedicao, horaMedicao, idMedidor) VALUES  
(220.000, 220.000, 220.000, 220.000, 220.000, 220.000, 1000.000, 800.000, 700.000, 220.000, 220.000, 220.000, 500.000, 400.000, 300.000, 10.000, 10.000, 10.000, 0.800, 1000.000, 800.000, 700.000, '2022-06-15', '09:32:00', 1),
(220.000, 220.000, 220.000, 220.000, 220.000, 220.000, 1200.000, 1000.000, 900.000, 220.000, 220.000, 220.000, 600.000, 500.000, 400.000, 12.000, 12.000, 12.000, 0.800, 1000.000, 800.000, 700.000, '2022-06-16','18:45:00', 2),
(220.000, 220.000, 220.000, 220.000, 220.000, 220.000, 1500.000, 1300.000, 1200.000, 220.000, 220.000, 220.000, 800.000, 700.000, 600.000, 15.000, 15.000, 15.000, 0.800, 1200.000, 1000.000, 900.000,'2022-06-17', '14:20:00', 3),
(220.000, 220.000, 220.000, 220.000, 220.000, 220.000, 1800.000, 1600.000, 1500.000, 220.000, 220.000, 220.000, 1000.000, 900.000, 800.000, 18.000, 18.000, 18.000, 0.800, 1400.000, 1200.000, 1100.000, '2022-06-18', '11:55:00', 4),
(220.000, 220.000, 220.000, 220.000, 220.000, 220.000, 2000.000, 1800.000, 1700.000, 220.000, 220.000, 220.000, 1200.000, 1100.000, 1000.000, 20.000, 20.000, 20.000, 0.800, 1600.000, 1400.000, 1300.000, '2022-06-19', '22:16:00', 5),
(220.000, 800.000, 1500.000, 1300.000, 1600.000, 12.000, 12.000, 700.000, 1500.000, 1800.000, 800.000, 1800.000, 220.000, 1300.000, 12.000, 0.800, 700.000, 500.000, 0.800, 500.000, 0.800, 800.000, '2022-06-20', '15:30:00', 1),
(700.000, 220.000, 600.000, 1600.000, 800.000, 1600.000, 220.000, 1300.000, 1800.000, 1300.000, 0.800, 700.000, 500.000, 0.800, 220.000, 1300.000, 1800.000, 500.000, 500.000, 1300.000, 220.000, 1500.000, '2022-06-21', '10:05:00', 2),
(800.000, 1300.000, 220.000, 600.000, 800.000, 1600.000, 700.000, 12.000, 1800.000, 220.000, 1500.000, 0.800, 1300.000, 1500.000, 500.000, 0.800, 500.000, 700.000, 500.000, 220.000, 0.800, 1800.000, '2022-06-22', '08:12:00', 3),
(1500.000, 1300.000, 600.000, 1600.000, 700.000, 1600.000, 1800.000, 220.000, 1300.000, 1500.000, 700.000, 500.000, 12.000, 500.000, 700.000, 500.000, 800.000, 500.000, 500.000, 500.000, 0.800, 1500.000, '2022-06-23', '19:55:00', 4),
(1300.000, 600.000, 1600.000, 220.000, 1600.000, 12.000, 800.000, 1800.000, 220.000, 1300.000, 700.000, 0.800, 800.000, 500.000, 700.000, 12.000, 0.800, 700.000, 500.000, 500.000, 0.800, 800.000, '2022-06-24', '16:28:00', 5);


INSERT INTO MEDIDAACUMULADA (consumoPonta, consumoForaPonta, energiaGerada, energiaIndutiva, energiaCapacitiva, maxPotenciaAtiva, maxPotenciaReativaAcumulada, tipoMedida, dataMedicao, horaMedicao, idMedidor) VALUES
(100.0, 300.0, 50.0, 30.0, 20.0, 2000.0, 1500.0, '1', '2022-07-25', '12:30:00', 1),
(200.0, 800.0, 70.0, 40.0, 30.0, 2100.0, 1600.0, '1', '2023-01-06', '15:45:00', 2),
(300.0, 300.0, 90.0, 50.0, 40.0, 2200.0, 1700.0, '1', '2022-10-18', '06:15:00', 3),
(400.0, 500.0, 110.0, 60.0, 50.0, 2300.0, 1800.0, '1', '2023-08-02', '17:00:00', 4),
(500.0, 550.0, 130.0, 70.0, 60.0, 2400.0, 1900.0, '2', '2022-11-29', '03:45:00', 5),
(550.0, 500.0, 150.0, 80.0, 70.0, 2500.0, 2000.0, '2', '2023-09-12', '09:20:00', 5),
(500.0, 400.0, 170.0, 90.0, 80.0, 2600.0, 2100.0, '2', '2022-09-25', '14:55:00', 2),
(300.0, 300.0, 190.0, 100.0, 90.0, 2700.0, 2200.0, '2', '2023-04-06', '10:12:00', 2),
(800.0, 200.0, 210.0, 110.0, 100.0, 2800.0, 2300.0, '2', '2022-07-15', '21:45:00', 3),
(300.0, 100.0, 230.0, 120.0, 110.0, 2900.0, 2400.0, '2', '2023-01-20', '18:18:00', 1);


INSERT INTO TARIFA (modalidade, subgrupo, tusdKWPonta, tusdKWForaPonta, tusdKWNa, tusdMWPonta, tusdMWForaPonta, tusdMWNa, teMWPonta, teMWForaPonta, teMWNa, cnpjDistribuidora) VALUES
(1, 'Subgrupo A1', 89.29, 115.60, 250.80, 111.13, 189.30, 413.03, 156.77, 109.87, 89.60, 03353055000196),
(0, 'Subgrupo B1', 95.04, 124.90, 189.30, 97.13, 387.20, 393.03, 333.60, 134.52, 298.24, 03353055000196),
(1, 'Subgrupo A2', 156.77, 298.24, 503.99, 66.42, 142.30, 427.50, 89.60,  82.70, 142.30, 98416126000146),
(0, 'Subgrupo B2', 66.42, 109.87, 224.15, 89.29, 109.87, 124.90, 298.24, 156.77, 134.52, 98416126000146),
(1, 'Subgrupo A3', 134.52, 217.89, 398.27, 66.42, 89.29, 387.20, 109.87,  142.30, 95.04, 49360787000191),
(0, 'Subgrupo B3', 78.50, 103.20, 333.60, 387.20, 124.90, 142.30, 156.77, 115.60, 156.77, 92019603000153),
(1, 'Subgrupo A4', 142.30, 201.10, 427.50, 78.50, 240.40, 89.60, 124.90, 134.52,  134.52, 48243211000181),
(0, 'Subgrupo B4', 64.80, 89.60, 240.40, 217.89, 427.50, 78.50, 109.87, 156.77, 134.52, 69720712000181),
(1, 'Subgrupo AS', 124.90, 189.30, 387.20, 89.29, 427.50, 156.77, 333.60, 134.52, 217.89, 21023783000107),
(0, 'Subgrupo A3a', 82.70, 115.60, 250.80, 427.50, 142.30, 201.10, 82.70, 124.90, 333.60, 23836916000181);


INSERT INTO PERFIL (tipo, descricao) VALUES
('Admin', 'Perfil de admin feito para gerir todo o sistema'),
('Pesquisador', 'Perfil de pesquisador, pode gerar relatórios'),
('Geral', 'Perfil geral, pode visualizar dados de maneria limitada'),
('Gestor de Energia', 'Gere e controla o sistema de energia'),
('Gestor de Distribuição', 'Gere e controla o sistema de distribuição'),
('Analista de Dados', 'Responsável por analisar e interpretar os dados coletados'),
('Técnico de Manutenção', 'Realiza a manutenção e reparo nos medidores e equipamentos'),
('Coordenador de Projetos', 'Coordena a execução de projetos relacionados à energia'),
('Engenheiro Eletricista', 'Responsável por projetos e análises elétricas'),
('Assistente Administrativo', 'Auxilia nas tarefas administrativas do sistema');


INSERT INTO USUARIO (email, senha, nome, idPerfil) VALUES
('cicero.barrozo13@gmail.com', 'dev123', 'Cicero Fernandes', 1),
('renatosampaio@gmail.com', 'renato@1s', 'Renato Sampaio', 2),
('igormanoel@gmail.com', 'igm021', 'Igor Manoel', 3),
('caio.fernandes@gmail.com', 'cfcaio', 'Caio Fernandes', 5),
('alexander.wilson@gmail.com', 'senha123', 'Alexander', 4),
('maria.silva@gmail.com', 'mariasilva', 'Maria Silva', 7),
('lucas.rodrigues@gmail.com', 'lucas@123', 'Lucas Rodrigues', 6),
('juliana.ferreira@gmail.com', 'juferreira', 'Juliana Ferreira', 8),
('gabriel.lopes@gmail.com', 'gab123', 'Gabriel Lopes', 10),
('carla.andrade@gmail.com', 'carla123', 'Carla Andrade', 9);


INSERT INTO TIPOEVENTO (tipo) VALUES
('Tensão Precária'),
('Tensão Crítica'),
('Queda de Fase'),
('Falta de Energia'),
('Potência Acima da Nominal'),
('Surtos de Energia'),
('Desarme de Disjuntor'),
('Alta Distorção Harmônica'),
('Baixa Distorção Harmônica'),
('Sobrecarga');


INSERT INTO EVENTO (dataInicio, horaInicio, idMedidor, idTipoEvento) VALUES
('2023-05-13', '23:06:00', 1, 1),
('2023-06-08', '15:45:00', 1, 2),
('2023-04-22', '16:10:00', 3, 3),
('2023-06-19', '12:00:00', 4, 4),
('2023-03-11', '13:00:00', 5, 5),
('2023-07-01', '09:30:00', 6, 6),
('2023-06-25', '20:15:00', 7, 7),
('2023-07-08', '14:20:00', 8, 8),
('2023-07-05', '17:30:00', 9, 9),
('2023-06-30', '10:00:00', 10, 10);


INSERT INTO CONTRATO (numeroContrato, inicioVigencia, prazoVigencia, tensaoDeFornecimento, dataFechamento, demandaPonta, demandaForaPonta, idTarifa, numeroUnidade) VALUES
(1234567890, '2022-07-18', 12, 220.0, NULL, 100, 50, 1, 58297041),
(9876543210, '2023-09-03', 6, 230.0,  NULL, 150, 80, 2, 19382567),
(5678901234, '2022-11-29', 24, 240.0, NULL, 200, 100, 3, 73910482),
(8765432109, '2023-02-14', 36, 250.0, NULL, 250, 120, 4, 65281937),
(3456789012, '2022-07-06', 48, 260.0, NULL, 300, 150, 5, 40732895),
(2345678901, '2023-04-30', 18, 210.0, NULL, 120, 60, 3, 25873014),
(8901234567, '2022-09-15', 12, 215.0, NULL, 130, 70, 4, 25873014),
(9012345678, '2023-01-25', 24, 225.0, NULL, 180, 90, 5, 36498275),
(6789012345, '2023-07-10', 36, 235.0, NULL, 220, 110, 1, 52971836),
(4567890123, '2022-12-01', 48, 245.0, NULL, 280, 140, 2, 89103625);


