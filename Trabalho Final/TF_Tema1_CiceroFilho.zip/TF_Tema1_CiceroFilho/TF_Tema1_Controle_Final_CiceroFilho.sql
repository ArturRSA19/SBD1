-- -------- < TF1 - ENERGIA > --------
-- 
--                    SCRIPT DE CONTROLE 
-- 
-- Data Criacao ...........: 19/07/2023
-- Autor(es) ..............: Ana César, Ana Silva, Artur Alves, Breno Souza, Bruna Santos, Bruno Ribeiro, Bruno Kishibe, Cícero Filho, 
--                           Chaydson Aparecida, Damarcones Portos, Douglas Santos, Eric Borges, Erick Santos, Felipe Macedo

-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: TF_Tema1_cicerofilho
-- 
-- PROJETO => 01 Base de Dados
--         => 17 Tabelas
--         => 03 perfis
--         => 03 usuarios
-- 
-- -----------------------------------------------------------------

-- BASE DE DADOS

USE TF_Tema1_cicerofilho;


-- PERFIS (ou Role)
CREATE ROLE IF NOT EXISTS gestor;
CREATE ROLE IF NOT EXISTS pesquisador;
CREATE ROLE IF NOT EXISTS geral;



-- PRIVILEGIOS
GRANT ALL PRIVILEGES ON TF_Tema1_cicerofilho.* TO gestor;

GRANT select ON TF_Tema1_cicerofilho.* TO pesquisador;

GRANT SELECT ON TF_Tema1_cicerofilho.CAMPUS TO geral;
GRANT SELECT ON TF_Tema1_cicerofilho.UNIDADECONSUMIDORA TO geral;
GRANT SELECT ON TF_Tema1_cicerofilho.EDIFICACAO TO geral;
GRANT SELECT ON TF_Tema1_cicerofilho.CHAVEELETRICA TO geral;
GRANT SELECT ON TF_Tema1_cicerofilho.LINHATRANSMISSAO TO geral;
GRANT SELECT ON TF_Tema1_cicerofilho.MEDIDOR TO geral;
GRANT SELECT ON TF_Tema1_cicerofilho.pontoTransmissao TO geral;

-- USUARIOS
CREATE USER 'renato' IDENTIFIED BY 'renato123';

CREATE USER 'cicero'IDENTIFIED BY 'cicero123';

CREATE USER 'milene' IDENTIFIED BY 'milene123';


-- ASSOCIA USUARIOS AOS PERFIS
GRANT gestor TO renato;
GRANT pesquisador TO cicero;
GRANT geral TO milene;


FLUSH PRIVILEGES;
