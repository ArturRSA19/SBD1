-- ------------------------------ << TF1 >> -----------------------------------
--                          SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Artur Rodrigues Sousa Alves e Bruno Campos Ribeiro
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: BrunoRibeiro
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
-- 
-- Ultimas Alteracoes
--   18/06/2023 => Criação do SCRIPT
--
-- -----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS BrunoRibeiro;
    
USE BrunoRibeiro;

CREATE TABLE EDIFICACAO (
    idEdificacao INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL,
    latitude DECIMAL(6,4) NOT NULL,
    longitude DECIMAL(6,4) NOT NULL,
    CONSTRAINT EDIFICACAO_PF PRIMARY KEY (idEdificacao)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE DISTRIBUIDORA (
    cnpj BIGINT NOT NULL AUTO_INCREMENT,
    razaoSocial VARCHAR(80) NOT NULL,
    sigla VARCHAR(10) NOT NULL,
    CONSTRAINT DISTRIBUIDORA_PK PRIMARY KEY (cnpj)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE TARIFA (
    idTarifa INTEGER NOT NULL AUTO_INCREMENT,
    tusdKw DECIMAL(8,2) NOT NULL,
    tusdMwh DECIMAL(8,2) NOT NULL,
    te DECIMAL(8,2) NOT NULL,
    subgrupo VARCHAR(30) NOT NULL,
    modalidade VARCHAR(30) NOT NULL,
    cnpj BIGINT NOT NULL, 
    CONSTRAINT TARIFA_PK PRIMARY KEY (idTarifa),
    CONSTRAINT TARIFA_DISTRIBUIDORA_FK FOREIGN KEY (cnpj) REFERENCES DISTRIBUIDORA(cnpj)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE CONTRATO (
    numeroContrato INTEGER NOT NULL AUTO_INCREMENT,
    dataVigencia DATE NOT NULL,
    categoria ENUM('residencial', 'industrial', 'comercial', 'rural', 'poder público') NOT NULL,
    tensaoContratada DECIMAL(8,2) NOT NULL,
    idTarifa INTEGER NOT NULL, 
    CONSTRAINT CONTRATO_PK PRIMARY KEY (numeroContrato),
    CONSTRAINT CONTRATO_TARIFA_FK FOREIGN KEY (idTarifa) REFERENCES TARIFA(idTarifa)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE UNIDADE (
    numeroUnidade INTEGER NOT NULL AUTO_INCREMENT,
    sigla VARCHAR(10) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    idEdificacao INTEGER NOT NULL,
    numeroContrato INTEGER NOT NULL, 
    CONSTRAINT UNIDADE_PK PRIMARY KEY (numeroUnidade),
    CONSTRAINT UNIDADE_CONTRATO_FK FOREIGN KEY (numeroContrato) REFERENCES CONTRATO(numeroContrato),
    CONSTRAINT UNIDADE_EDIFICACAO_FK FOREIGN KEY (idEdificacao) REFERENCES EDIFICACAO(idEdificacao)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE CAMPUS (
    idCampus INTEGER NOT NULL AUTO_INCREMENT,
    sigla VARCHAR(10) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    latitude DECIMAL(6,4) NOT NULL,
    longitude DECIMAL(6,4) NOT NULL,
    numeroUnidade INTEGER NOT NULL,  
    CONSTRAINT CAMPUS_PK PRIMARY KEY (idCampus),
    CONSTRAINT CAMPUS_UNIDADE_FK FOREIGN KEY (numeroUnidade) REFERENCES UNIDADE(numeroUnidade)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE CHAVE (
    idChave INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL,
    estado BIT(1) NOT NULL,
    latitude DECIMAL(6,4) NOT NULL,
    longitude DECIMAL(6,4) NOT NULL,
    CONSTRAINT CHAVE_PK PRIMARY KEY (idChave)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE LINHA (
    idLinha INTEGER NOT NULL AUTO_INCREMENT,
    pontoFinalLatitude DECIMAL(6,4) NOT NULL,
    pontoFinalLongitude DECIMAL(6,4) NOT NULL,
    pontoInicialLatitude DECIMAL(6,4) NOT NULL,
    pontoInicialLongitude DECIMAL(6,4) NOT NULL,
    estado BIT(1) NOT NULL,
    idChave INTEGER NOT NULL, 
    CONSTRAINT LINHA_PK PRIMARY KEY (idLinha),
    CONSTRAINT LINHA_CHAVE_FK FOREIGN KEY (idChave) REFERENCES CHAVE(idChave)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE MEDIDOR (
	ip INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL,
    corrente DECIMAL(8,2) NOT NULL,
    tensao INTEGER NOT NULL,
    potenciaAtiva DECIMAL(8,2) NOT NULL,
    potenciaReativa DECIMAL(8,2) NOT NULL,
    potenciaAparente DECIMAL(8,2) NOT NULL,
    fatorDePotencia DECIMAL(4,2) NOT NULL,
    dhtTensao DECIMAL(4,2) NOT NULL,
    dhtCorrente DECIMAL(4,2) NOT NULL,
    modelo VARCHAR(30) NOT NULL,
    fabricante VARCHAR(30) NOT NULL,
    porta INTEGER NOT NULL,
    latitude DECIMAL(6,4) NOT NULL,
    longitude DECIMAL(6,4) NOT NULL,
    estado BIT(1) NOT NULL,
    idEdificacao INTEGER NOT NULL, 
    idLinha INTEGER NOT NULL, 
    CONSTRAINT MEDIDOR_PK PRIMARY KEY (ip),
    CONSTRAINT MEDIDOR_EDIFICACAO_FK FOREIGN KEY (idEdificacao) REFERENCES EDIFICACAO(idEdificacao),
    CONSTRAINT MEDIDOR_LINHA_FK FOREIGN KEY (idLinha) REFERENCES LINHA(idLinha)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE EVENTO (
    idEvento INTEGER AUTO_INCREMENT,
    hora TIME NOT NULL,
    dataEvento DATE NOT NULL,
    tipoEvento ENUM('muito abaixo', 'abaixo', 'dentro', 'acima', 'muito acima') NOT NULL,
    CONSTRAINT EVENTO_PK PRIMARY KEY (idEvento)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE USUARIO (
    email VARCHAR(30) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    senha VARCHAR(30) NOT NULL,
    idCampus INTEGER NOT NULL, 
    CONSTRAINT USUARIO_PK PRIMARY KEY (email)
)ENGINE=InnoDB;
 