-- ------------------------------ << TF1 >> -----------------------------------
--                          SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Artur Rodrigues Sousa Alves e Bruno Campos Ribeiro
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF1B1
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
-- 
-- Ultimas Alteracoes
--   18/06/2023 => Apagando as tabelas
--
-- -----------------------------------------------------------------------------

USE TF1B1;

DROP TABLE USUARIO;
DROP TABLE EVENTO;
DROP TABLE MEDIDOR;
DROP TABLE LINHA;
DROP TABLE CHAVE;
DROP TABLE CAMPUS;
DROP TABLE UNIDADE;
DROP TABLE CONTRATO;
DROP TABLE TARIFA;
DROP TABLE DISTRIBUIDORA;
DROP TABLE EDIFICACAO;










