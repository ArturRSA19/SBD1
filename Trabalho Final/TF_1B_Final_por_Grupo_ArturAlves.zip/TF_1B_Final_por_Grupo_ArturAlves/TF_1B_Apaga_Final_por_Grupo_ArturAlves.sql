-- ------------------------------ << TF1 >> -----------------------------------
--                          SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 18/06/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves, Bruno Campos Ribeiro, Bruno Seiji Kishibe e Erick Levy Barbosa dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF1B1
--
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
-- 
-- Ultimas Alteracoes
--   18/06/2023 => Apagando as tabelas
--   03/07/2023 => Apagando as 3 novas tabelas
--   17/07/2023 => Adicionando objetos a serem apagados
-- -----------------------------------------------------------------------------

USE TF_1B1_BrunoRibeiro;

DROP TABLE USUARIO;
DROP TABLE EVENTO;
DROP TABLE MEDIDAACUMULADA;
DROP TABLE MEDIDAINSTANTANEA;
DROP TABLE MEDIDA;
DROP TABLE MEDIDOR;
DROP TABLE LINHA;
DROP TABLE CHAVE;
DROP TABLE CAMPUS;
DROP TABLE UNIDADE;
DROP TABLE CONTRATO;
DROP TABLE TARIFA;
DROP TABLE DISTRIBUIDORA;
DROP TABLE EDIFICACAO;
DROP USER 'João';
DROP USER 'Pedro';
DROP USER 'George';
DROP ROLE Gestor;
DROP ROLE Pesquisador;
DROP ROLE Geral;










