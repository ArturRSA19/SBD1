-- ------------------------------ << TF1 >> -----------------------------------
--                          SCRIPT DE POPULA (DDL)
--
-- Data Criacao ...........: 18/06/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves, Bruno Campos Ribeiro, Bruno Seiji Kishibe e Erick Levy Barbosa dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF1B1
--
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
-- 
-- Ultimas Alteracoes
--   18/06/2023 => Populando as tabelas com pelo menos 5 tuplas
--   03/07/2023 => Populando as 3 novas tabelas com pelo menos 5 tuplas
--   17/07/2023 => Alteração nas tabelas e melhoramento do projeto
-- -----------------------------------------------------------------------------

USE TF_1B1_BrunoRibeiro;

INSERT INTO EDIFICACAO (idEdificacao,nome, latitude, longitude) VALUES
    (1,'ICC-FAC', -15.7660, -47.8681),
    (2,'BCE', -15.7609, -47.8704),
    (3,'FCS', -15.7685, -47.8669),
    (4,'UAC', -15.9893, -48.0407),
    (5,'UAC', -15.8441, -48.1015),
    (6,'Lab Engenharia Civil', -15.7650, -47.8726),
    (7,'FAV', -15.7641, -47.8683),
	(8,'RU', -15.7645 , -47.8706),
    (9,'ICC', -15.7630, -47.8695),
    (10,'FAC', -15.7661, -47.8712);
    
INSERT INTO DISTRIBUIDORA (cnpj, razaoSocial, sigla) VALUES
    (33050071000158, 'Companhia de Eletricidade do Estado do Rio de Janeiro', 'CERJ'),
    (33050196000188, 'Companhia Paulista de Força e Luz', 'CPFL'),
    (11221326000165,'Companhia Energética de Minas Gerais', 'CEMIG'),
    (76483817000120,'Companhia Paranaense de Energia', 'COPEL'),
    (61695227000193,'Eletropaulo Metropolitana Eletricidade de São Paulo', 'ENEL'),
	(07522669000192, 'NEOENERGIA DISTRIBUIÇÃO BRASÍLIA', 'NEO3'),
	(15139629000194, 'COMPANHIA DE ELETRICIDADE DO ESTADO DA BAHIA COELBA', 'COELBA'),
	(19527639000158, 'ENERGISA MINAS RIO - DISTRIBUIDORA DE ENERGIA S.A.', 'ENERGISA'),
    (83855973000130,'DCELT DISTRIBUIDORA CATARINENSE DE ENERGIA ELETRICA S/A','DCELT'),
	(08222907000107,'CHEA - CENTRAIS HIDRELETRICAS DA AMAZONIA LTDA','CHEA');
    
INSERT INTO TARIFA (tusdKw, tusdMwh, te, subgrupo, modalidade, cnpj) VALUES
    (10.50, 150.00, 5.75, 'Residencial', 'Azul', 33050196000188),
    (15.25, 200.00, 7.80, 'Comercial', 'Verde', 11221326000165),
    (8.75, 120.00, 4.50, 'Residencial', 'Azul', 61695227000193),
    (12.50, 180.00, 6.80, 'Industrial', 'Verde', 15139629000194),
    (9.80, 130.00, 5.25, 'Residencial', 'Verde', 07522669000192),
    (15.10, 31.00, 0.39, 'A2', 'Azul', 33050071000158),
	(30.20, 60.00, 0.24, 'A3a', 'Verde', 19527639000158),
	(9.62, 18.82, 0.26, 'A2', 'Azul', 76483817000120),
	(30.20, 60.01, 0.24, 'A3a', 'Branca', 33050071000158),
	(9.62, 18.82, 0.26, 'A4', 'Azul', 33050196000188);
    
INSERT INTO CONTRATO (numeroContrato, dataVigencia, categoria, tensaoContratada, idTarifa) VALUES
    (2345677, '2022-01-15', 'residencial', 220, 1),
    (1234569, '2021-09-30', 'industrial', 380, 2),
    (1234566, '2023-03-10', 'comercial', 220, 3),
    (5678905, '2023-03-15', 'rural', 380, 4),
    (5678909, '2021-11-05', 'poder público', 220, 5),
    (1234567, '2022-01-01', 'poder público', 130, 6),
	(2345678, '2023-02-01', 'poder público', 380, 7),
	(3456789, '2023-03-01', 'poder público', 480, 8),
	(4567890, '2024-04-01', 'poder público', 180, 9),
	(5678901, '2025-05-01', 'poder público', 200, 10);

INSERT INTO UNIDADE (sigla, nome, idEdificacao, numeroContrato) VALUES
    ('APT101', 'Apartamento 101', 1, 2345677),
    ('APT202', 'Apartamento 202', 2, 1234569),
    ('CASA01', 'Casa 01', 3, 1234566),
    ('LOJA01', 'Loja 01', 4, 5678905),
    ('SALA01', 'Sala 01', 5, 5678909),
	('FGA', 'FACULDADE DO GAMA', 6, 1234567),
	('DARCY', 'DARCY RIBEIRO', 7, 2345678),
	('CEPLAN', 'FACULDADE PLANALTINA', 8, 3456789),
	('ICC', 'INSTITUTO CENTRAL DE CIÊNCIAS', 9, 4567890),
	('FCE', 'FACULDADE DE CEILÂNDIA', 10, 5678901);

INSERT INTO CAMPUS (sigla, nome, latitude, longitude, numeroUnidade) VALUES
    ('UNB', 'Campus Darcy Ribeiro', -15.7660, -47.8681, 1),
    ('UNB', 'Campus Darcy Ribeiro', -15.7609, -47.8704, 2),
    ('UNB', 'Campus Darcy Ribeiro', -15.7685, -47.8669, 3),
    ('FGA', 'Campus Gama', -15.9893, -48.0407, 4),
    ('FCE', 'Campus Ceilândia', -15.8441, -48.1015, 5),
    ('CEPLAN', 'Campus Planaltina', -15.7642, -47.8722, 6),
    ('UNB', 'Campus Darcy Ribeiro', -15.7630, -47.8695, 7),
    ('DARCY', 'Campus Darcy Ribeiro', -15.7658, -47.8721, 8),
    ('FCE', 'Campus Ceilândia', -15.8442, -48.1016, 9),
    ('FGA', 'Campus Gama', -15.9894, -48.0406, 4);
    

INSERT INTO CHAVE (nome, estado, latitude, longitude) VALUES
    ('Chave A', 1, -15.7660, -47.8681),
    ('Chave B', 0, -15.7609, -47.8704),
    ('Chave C', 1, -15.7685, -47.8669),
    ('Chave D', 1, -15.9893, -48.0407),
    ('Chave E', 0, -15.8441, -48.1015),
    ('Chave1', 1, -15.7641, -47.8683),
	('Chave2', 0, -15.7650, -47.8726),
	('Chave3', 1, -15.7661, -47.8712),
	('Chave4', 0, -15.7645 , -47.8706),
	('Chave5', 1, -15.7661, -47.8712);

INSERT INTO LINHA (pontoFinalLatitude, pontoFinalLongitude, pontoInicialLatitude, pontoInicialLongitude, estado, idChave) VALUES
    (-15.7660, -47.8681, -15.7573, -47.8718, 1, 1),
    (-15.7609, -47.8704, -15.7605, -47.8679, 1, 2),
    (-15.7685, -47.8669, -15.7665, -47.8649, 0, 3),
    (-15.9893, -48.0407, -15.9898, -48.0454, 1, 4),
    (-15.8441, -48.1015, -15.8441, -48.1006, 0, 5),
    (-15.7641, -47.8683, -15.7650, -47.8726, 1, 6),
	(-15.7650, -47.8726, -15.7641, -47.8683, 0, 7),
	(-15.7661, 47.8712, -15.7630, -47.8695, 1, 8),
	(-15.7645, -47.8706, -15.7641, -47.8683, 0, 9),
	(-15.7641, -47.868, -15.7661, -47.8712, 1, 10);

INSERT INTO MEDIDOR (ip, nome, modelo, fabricante, porta, latitude, longitude, estado, idEdificacao, idLinha) VALUES
    (80215400, 'Medidor 1', 'EMBRASUL MD30', 'EMBRASUL', 1, -15.7660, -47.8681, 1, 1, 1),
    (19202100, 'Medidor 2', 'EMBRASUL MD30', 'EMBRASUL', 2, -15.7609, -47.8704, 0, 2, 2),
    (21658211, 'Medidor 3', 'EMBRASUL TR4020', 'EMBRASUL', 3, -15.7685, -47.8669, 1, 3, 3),
    (20301134, 'Medidor 4', 'EMBRASUL TR4020', 'EMBRASUL', 4, -15.9893, -48.0407, 1, 4, 5),
    (13456847, 'Medidor 5', 'EMBRASUL TR4020', 'EMBRASUL', 5, -15.8441, -48.1015, 0, 5, 5),
    (15997120, 'Medidor 6', 'EMBRASUL TR4020', 'EMBRASUL', 1030, -15.7650, -47.8726, 1, 6, 6),
    (22393149, 'Medidor 7', 'EMBRASUL TR4020', 'EMBRASUL', 8080, -15.7641, -47.8683, 0, 7, 7),
    (15218224, 'Medidor 8', 'EMBRASUL TR4020', 'EMBRASUL', 1024, -15.7645, -47.8706, 0, 8, 8),
    (46251393, 'Medidor 9', 'EMBRASUL MD30', 'EMBRASUL', 8888, -15.7630, -47.8695, 1, 9, 4),
    (65917130, 'Medidor 10', 'EMBRASUL MD30', 'EMBRASUL', '3333', -15.7661, -47.8712, 1, 10, 5);
    
INSERT INTO MEDIDA (dataMedida, ip) VALUES
	('2023-06-15', 80215400),
    ('2023-07-02', 21658211),
    ('2023-04-03', 13456847),
    ('2023-05-19', 22393149),
    ('2023-03-21', 65917130);

INSERT INTO MEDIDAINSTANTANEA (corrente, tensao, potenciaAtiva, potenciaReativa, potenciaAparente, fatorDePotencia, dhtTensao, dhtCorrente, idMedida) VALUES
	(10.5, 220, 2000, 800, 2200, 0.9, 2.5, 1.8, 1),
    (15.2, 380, 3000, 1200, 3500, 0.85, 2.2, 1.6, 2),
    (7.8, 220, 1500, 600, 1800, 0.92, 2.4, 1.7, 3),
    (12.6, 380, 2500, 1000, 3000, 0.88, 2.3, 1.5, 2),
    (9.3, 220, 1800, 700, 2000, 0.91, 2.4, 1.6, 1),
    (550.25, 370.50, 450.75, 200.25, 180.50, 0.9, 12.56, 1.8, 1),
	(480.60, 320.40, 400.25, 175.80, 160.60, 0.9, 95.80, 1.7, 2),
	(590.80, 410.75, 490.60, 220.40, 200.80, 0.88, 18.20, 1.6, 3),
	(450.20, 300.80, 350.40, 155.70, 140.80, 0.91, 80.40, 1.7, 4),
	(520.90, 360.20, 420.60, 190.50, 170.90, 0.88, 95.50, 1.8, 5);

INSERT INTO MEDIDAACUMULADA (correnteAcumulada, tensaoAcumulada, potenciaAtivaAcumulada, potenciaReativaAcumulada, potenciaAparenteAcumulada, fatorDePotenciaAcumulada, dhtTensaoAcumulada, dhtCorrenteAcumulada, idMedida) VALUES
	(10.5, 220, 2000, 800, 2200, 0.9, 2.5, 1.8, 1),
    (15.2, 380, 3000, 1200, 3500, 0.85, 2.2, 1.6, 2),
    (7.8, 220, 1500, 600, 1800, 0.92, 2.4, 1.7, 3),
    (12.6, 380, 2500, 1000, 3000, 0.88, 2.3, 1.5, 4),
    (9.3, 220, 1800, 700, 2000, 0.91, 2.4, 1.6, 2),
    (220.50, 10.75, 2367.85, 120.25, 2500.30, 0.95, 1.6, 1,1),
	(205.10, 8.35, 1568.40, 80.75, 1700.20, 0.92, 1.7, 2,2),
	(230.20, 9.80, 1980.60, 102.80, 2100.50, 0.94, 1.8, 3,3),
	(195.80, 7.60, 1345.70, 65.20, 1500.90, 0.88, 1.6, 4,4),
	(210.60, 9.10, 1763.50, 94.75, 1900.10, 0.91, 1.7, 5,5);
    
INSERT INTO EVENTO (hora, dataEvento, tipoEvento) VALUES
    ('08:30:00', '2023-06-15', 'acima'),
    ('12:45:00', '2023-06-16', 'muito acima'),
    ('18:15:00', '2023-06-17', 'dentro'),
    ('09:10:00', '2023-06-17', 'abaixo'),
    ('14:20:00', '2023-06-18', 'dentro'),
    ('08:30:00', '2023-06-20', 'acima'),
    ('12:45:00', '2023-06-21', 'muito acima'),
    ('18:15:00', '2023-06-22', 'dentro'),
    ('09:10:00', '2023-06-23', 'abaixo'),
    ('14:20:00', '2023-06-24', 'dentro');
    
INSERT INTO USUARIO (email, nome, senha, idCampus) VALUES
    ('pedro123@hotmail.com', 'PedroMN_12', 'Pedrorrrii11', 1),
    ('1matheus1@gmail.com', 'Matheus_11', 'asdadMatheus', 2),
    ('98carla@hotmail.com', 'Carla_98', 'Carla981723', 3),
    ('Rodrigo17@outlook.com', 'Rodrigo17', 'rodrigorr123', 4),
    ('jv_10@gmail.com', 'Jv_10', 'jv12345', 5),
    ('vandor@unb.br', 'VANDOR ROBERTO VILARDI RISSOLI', 'bancodedados1e2', 1),
	('edsonalves@unb.br', 'EDSON ALVES DA COSTA JUNIOR', 'compiladoresTep', 2),
	('ricardoajax@unb.br', 'RICARDO AJAX DIAS KOSLOSKI','QualidadeEpi1', 3),
	('mileneserrano@unb.br', 'MILENE SERRANO', 'ArquiteturaParadgimada', 5),
	('renatocoral@unb.br', 'RENATO CORAL SAMPAIO', 'senha654', 6);

