-- ------------------------------ << TF1 >> -----------------------------------
--                          SCRIPT DE CRIAÇÂO (DDL)
--
-- Data Criacao ...........: 03/07/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves, Bruno Campos Ribeiro, Bruno Seiji Kishibe e Erick Levy Barbosa dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF1B1
--
-- PROJETO => 01 Base de Dados
--         => 2 Tabelas
-- 
-- Ultimas Alteracoes
--   03/07/2023 => Criando dois perfis de usuário com privilégios de acesso diferentes.
-- -----------------------------------------------------------------------------

USE TF_1B1_BrunoRibeiro;

CREATE USER 'João' IDENTIFIED BY 'joao1010';
CREATE USER 'Pedro' IDENTIFIED BY 'senha2233';
CREATE USER 'George' IDENTIFIED BY 'curiosoidade123';

CREATE ROLE Gestor;
CREATE ROLE Pesquisador;
CREATE ROLE Geral;

GRANT ALL privileges ON TF_1B1_BrunoRibeiro.* TO Gestor; -- Gestor --

GRANT SELECT ON TF_1B1_BrunoRibeiro.* TO Geral; -- Geral --

GRANT SELECT, INSERT, UPDATE, DELETE ON TF_1B1_BrunoRibeiro.* TO Pesquisador; -- Pesquisador --

GRANT Gestor TO 'George';
GRANT Geral TO 'João';
GRANT Pesquisador TO 'Pedro';