-- -------- < aula4exer6Evolucao4_Apaga > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 10/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: bdInfracao
--
-- PROJETO => 01 Base de Dados
--         => 09 tabelas
--        
-- 
-- Ultimas Alteracoes 
--
--  10/05/223 => Criação do sql apaga.
-- ---------------------------------------------------------

USE aula4exer6Evolucao4;


DROP TABLE IF EXISTS INFRACAO;
DROP TABLE IF EXISTS TIPOINFRACAO;
DROP TABLE IF EXISTS AGENTE;
DROP TABLE IF EXISTS LOCAL;
DROP TABLE IF EXISTS VEICULO;
DROP TABLE IF EXISTS CATEGORIA;
DROP TABLE IF EXISTS MODELO;
DROP TABLE IF EXISTS telefone;
DROP TABLE IF EXISTS PROPRIETARIO;

