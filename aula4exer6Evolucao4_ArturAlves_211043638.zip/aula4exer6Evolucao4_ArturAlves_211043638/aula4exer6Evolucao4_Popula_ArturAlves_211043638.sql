-- -------- < aula4exer6Evolucao4_Popula > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 08/05/2023
-- Autor(es) ..............: Artur Rodrigues Sousa Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao4
--
-- PROJETO => 01 Base de Dados
--         => 09 tabelas
--        
-- 
-- Ultimas Alteracoes
--   22/05/2023 => Criação de um novo script para inserir dados na base de dados
-- ---------------------------------------------------------

USE aula4exer6Evolucao4;

INSERT INTO VEICULO (placaVeiculo, chassi, corPredominante, idCategoria, idModelo, anoFabricacao, cpf)
VALUES 
  ('ABC1234', '1A2B3C4D5E6F7G8H', 'Preto', '01', '000001', '2022-01-01', '12345678900'),
  ('DEF5678', '9I8H7G6F5E4D3C2B1A', 'Branco', '02', '000002', '2021-03-15', '98765432100'),
  ('GHI9012', '0A1B2C3D4E5F6G7H', 'Vermelho', '03', '000003', '2023-07-22', '45678912300');

INSERT INTO PROPRIETARIO (cpf, nomeCompleto, telefone, sexo, dataNascimento, estado, cidade, bairro, rua, cep, numero, complemento)
VALUES 
  ('12345678900', 'Fulano de Tal', '(11) 987654321', 'M', '1990-05-15', 'São Paulo', 'São Paulo', 'Centro', 'Rua A', '01234567', 1234, 'Apartamento 1'),
  ('98765432100', 'Ciclana Silva', '(21) 999999999', 'F', '1985-12-10', 'Rio de Janeiro', 'Rio de Janeiro', 'Copacabana', 'Avenida B', '23456789', 5678, NULL),
  ('45678912300', 'Beltrano Oliveira', '(81) 123456789', 'M', '1995-08-20', 'Pernambuco', 'Recife', 'Boa Viagem', 'Travessa C', '98765432', 9012, 'Casa 2');

INSERT INTO telefone (telefone, cpf)
VALUES 
  (12345678900, '12345678900'),
  (98765432100, '98765432100'),
  (45678912300, '45678912300');
  
INSERT INTO MODELO (idModelo, nomeModelo)
VALUES 
  (1, 'Modelo A'),
  (2, 'Modelo B'),
  (3, 'Modelo C');

INSERT INTO CATEGORIA (idCategoria, nomeCategoria)
VALUES 
  (1, 'Categoria A'),
  (2, 'Categoria B'),
  (3, 'Categoria C');

INSERT INTO TIPOINFRACAO (idInfracao, nomeInfracao, valorCobrado)
VALUES 
  ('001', 'Infracao A', 50.00),
  ('002', 'Infracao B', 75.50),
  ('003', 'Infracao C', 100.00);

INSERT INTO AGENTE (matriculaAgente, nomeCompleto, dataContratacao)
VALUES 
  (12345678, 'Agente A', '2020-01-01'),
  (87654321, 'Agente B', '2018-05-15'),
  (98765432, 'Agente C', '2019-10-20');

INSERT INTO LOCAL (idLocal, latitude, longitude, velocidadePermitida)
VALUES 
  ('001', 42.1234, -71.5678, 60),
  ('002', 37.9876, -122.3456, 50),
  ('003', -22.3456, -43.2109, 70);

INSERT INTO INFRACAO (placaVeiculo, data, hora, idInfracao, idLocal, matriculaAgente, velocidade)
VALUES 
  ('ABC1234', '2023-05-20', '09:15:00', '001', '001', 12345678, 70),
  ('DEF5678', '2023-05-21', '14:30:00', '002', '002', 87654321, 55),
  ('GHI9012', '2023-05-22', '17:45:00', '003', '003', 98765432, 89);



